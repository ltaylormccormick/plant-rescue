package com.plantrescue.app.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Image as ImageIcon
import androidx.compose.material3.Button
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import com.plantrescue.app.network.IdentifyResult
import com.plantrescue.app.network.PlantMatch
import com.plantrescue.app.network.PlantNetApiService
import kotlinx.coroutines.launch
import java.io.File

private sealed class IdentifyUiState {
    object Idle : IdentifyUiState()
    object Loading : IdentifyUiState()
    data class Success(val matches: List<PlantMatch>) : IdentifyUiState()
    data class Error(val message: String) : IdentifyUiState()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IdentifyScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    var pendingCameraUri by remember { mutableStateOf<Uri?>(null) }
    var uiState by remember { mutableStateOf<IdentifyUiState>(IdentifyUiState.Idle) }

    // Gallery picker — no runtime permission needed on modern Android.
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            selectedImageUri = uri
            uiState = IdentifyUiState.Idle
        }
    }

    // Camera capture — writes to a FileProvider URI we prepared beforehand.
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        if (success && pendingCameraUri != null) {
            selectedImageUri = pendingCameraUri
            uiState = IdentifyUiState.Idle
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            val uri = createCameraOutputUri(context)
            pendingCameraUri = uri
            cameraLauncher.launch(uri)
        }
    }

    fun launchCamera() {
        val hasPermission = androidx.core.content.ContextCompat.checkSelfPermission(
            context, Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED

        if (hasPermission) {
            val uri = createCameraOutputUri(context)
            pendingCameraUri = uri
            cameraLauncher.launch(uri)
        } else {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    fun runIdentification() {
        val uri = selectedImageUri ?: return
        uiState = IdentifyUiState.Loading
        scope.launch {
            val file = copyUriToCacheFile(context, uri)
            if (file == null) {
                uiState = IdentifyUiState.Error("Couldn't read that photo — try picking it again.")
                return@launch
            }
            when (val result = PlantNetApiService.identify(listOf(file))) {
                is IdentifyResult.Success -> uiState = IdentifyUiState.Success(result.matches)
                is IdentifyResult.Failure -> uiState = IdentifyUiState.Error(result.message)
            }
        }
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Identify My Plant") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (selectedImageUri != null) {
                AsyncImage(
                    model = selectedImageUri,
                    contentDescription = "Selected plant photo",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(260.dp)
                        .clip(RoundedCornerShape(16.dp))
                )
                Spacer(modifier = Modifier.height(16.dp))
            } else {
                Text(
                    text = "Take or choose a clear, well-lit photo of a leaf, flower or fruit.",
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.padding(vertical = 32.dp)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = { launchCamera() },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Filled.CameraAlt, contentDescription = null)
                    Spacer(modifier = Modifier.height(0.dp))
                    Text("  Camera")
                }
                OutlinedButton(
                    onClick = {
                        galleryLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(ImageIcon, contentDescription = null)
                    Spacer(modifier = Modifier.height(0.dp))
                    Text("  Gallery")
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = { runIdentification() },
                enabled = selectedImageUri != null && uiState !is IdentifyUiState.Loading,
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Text("Identify this plant")
            }

            Spacer(modifier = Modifier.height(24.dp))

            when (val state = uiState) {
                is IdentifyUiState.Loading -> {
                    CircularProgressIndicator()
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Asking Pl@ntNet…", style = MaterialTheme.typography.bodyMedium)
                }
                is IdentifyUiState.Error -> {
                    Text(
                        text = state.message,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                is IdentifyUiState.Success -> {
                    if (state.matches.isEmpty()) {
                        Text("No confident match found — try a clearer photo.")
                    } else {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.Start
                        ) {
                            Text(
                                text = "Likely matches",
                                style = MaterialTheme.typography.titleMedium
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            state.matches.forEachIndexed { index, match ->
                                MatchRow(match = match, isTopMatch = index == 0)
                                Spacer(modifier = Modifier.height(8.dp))
                            }
                        }
                    }
                }
                IdentifyUiState.Idle -> Unit
            }
        }
    }
}

@Composable
private fun MatchRow(match: PlantMatch, isTopMatch: Boolean) {
    Column {
        Text(
            text = match.commonName ?: match.scientificName,
            style = if (isTopMatch) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyLarge
        )
        Text(
            text = "${match.scientificName} · ${match.confidencePercent}% confidence",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

/** Creates a fresh content:// URI in cache for the camera to write a JPEG into. */
private fun createCameraOutputUri(context: android.content.Context): Uri {
    val imagesDir = File(context.cacheDir, "images").apply { mkdirs() }
    val file = File(imagesDir, "capture_${System.currentTimeMillis()}.jpg")
    return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
}

/** Copies whatever URI we have (camera or gallery) into a plain cache File for upload. */
private fun copyUriToCacheFile(context: android.content.Context, uri: Uri): File? = try {
    val imagesDir = File(context.cacheDir, "upload").apply { mkdirs() }
    val outFile = File(imagesDir, "upload_${System.currentTimeMillis()}.jpg")
    context.contentResolver.openInputStream(uri)?.use { input ->
        outFile.outputStream().use { output -> input.copyTo(output) }
    }
    outFile
} catch (e: Exception) {
    null
}
