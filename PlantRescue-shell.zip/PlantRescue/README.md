# Plant Rescue — Android app shell (Stage 1)

**Identify • Diagnose • Grow** — a UK-focused grow-your-own companion app.

## What's here

This is the **Stage 1 app shell** from the project plan: branding, navigation,
and the five main screens as placeholders, wired together with Jetpack
Compose Navigation. Nothing talks to a network API yet — that's Stage 2.

- `HomeScreen` — the five big, obvious actions (📸 Identify, 🩺 Diagnose,
  🥕 Grow My Own, 🌿 My Garden, 📅 What Do I Do Now?)
- `PlaceholderScreen` — shared scaffold used by the five feature screens
  until each is built out
- `ui/theme/` — colour palette (leaf green + soil tones + a soft coral
  "rescue" accent used sparingly, kept deliberately non-clinical)
- `PlantRescueNavHost` — routes between Home and each feature screen

## Opening the project

1. Open this folder in **Android Studio** (Koala/2024.1 or newer recommended).
2. Let it sync — Android Studio will generate the Gradle wrapper JAR
   automatically the first time (this repo ships the wrapper *properties*
   but not the binary JAR, since it isn't practical to hand-write). If it
   doesn't prompt you, run `gradle wrapper` once from the project root with
   any local Gradle install, or use Android Studio's "Upgrade/repair Gradle
   wrapper" prompt.
3. Run on an emulator or device with **minSdk 26** (Android 8.0) or above.

## Tech choices and why

- **Kotlin + Jetpack Compose (native Android)**, not Flutter/React Native.
  The brief is explicit about Android-first with no near-term iOS need, and
  native gives the smoothest path to the things this app leans on early —
  CameraX, Play Billing, and eventually ML Kit — without a cross-platform
  layer in between. If iOS becomes a real goal later, the UI would need a
  rewrite either way; the app logic (diagnosis rules, crop data) is small
  enough that this isn't a heavy cost.
- **Compose Navigation** for the five sections, since the brief calls for a
  simple, flat structure rather than deep menus.
- No database or networking library added yet — deliberately, per the
  brief's "prove the UX first, don't spend on APIs yet" instruction (V1
  philosophy, section 18).

## Next steps (matches the brief's staged plan)

1. **Stage 1 (this shell):** add local storage (Room) for crops/photos,
   camera/photo-picker integration, and real content for the Grow Your Own
   crop list — still no external API calls.
2. **Stage 2:** wire up plant identification via the Pl@ntNet API. Verify
   current free-tier limits and terms before relying on them — they've
   changed before and the brief flags this explicitly.
3. **Stage 3:** build the diagnosis flow — guided questions plus a local
   rules engine for common problems (e.g. tomato blight, blossom-end rot),
   falling back to AI only where the rules can't resolve it, to keep API
   costs down.
4. **Stage 4:** My Garden (saved crops, history) and What To Do Now
   (current tasks per saved plant).
5. **Stage 5:** ads + Google Play Billing for the Pro tier.
6. **Stage 6:** testing with real UK plants and crops.

## Branding notes

Colour palette leans on leaf green and soil tones, with a soft coral used
only for the "diagnose" action — enough to signal "something needs
attention" without looking like a medical app, per the brief's branding
direction (plant + subtle rescue theme, not clinical).
