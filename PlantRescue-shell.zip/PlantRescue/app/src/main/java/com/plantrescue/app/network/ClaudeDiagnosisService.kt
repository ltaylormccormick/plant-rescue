package com.plantrescue.app.network

import com.plantrescue.app.BuildConfig
import com.plantrescue.app.diagnosis.Confidence
import com.plantrescue.app.diagnosis.DiagnosisResult
import com.plantrescue.app.diagnosis.PossibleProblem
import com.plantrescue.app.diagnosis.ProblemIcon
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Base64
import java.util.concurrent.TimeUnit

sealed class AiDiagnosisResult {
    data class Success(val result: DiagnosisResult) : AiDiagnosisResult()
    data class Failure(val message: String) : AiDiagnosisResult()
}

/**
 * Pro-tier "instant scan" diagnosis: one photo straight to Claude's vision
 * model, no guided questions. Unlike the free DiagnosisEngine flow (which is
 * pure local logic and costs nothing per use), every call here hits a paid
 * API — that's exactly why this sits behind Pro rather than the free tier,
 * per the brief's cost-control approach (section 12/14).
 *
 * There's no real Play Billing/Pro gate wired up yet (that's Stage 5) — for
 * now this is reachable directly for testing, since it's just Lee's own key.
 */
object ClaudeDiagnosisService {

    private const val URL = "https://api.anthropic.com/v1/messages"
    private const val MODEL = "claude-haiku-4-5-20251001"

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .build()

    private val prompt = """
        You are helping a UK home gardener work out what's wrong with a food
        crop plant from a photo. Look closely at the photo and identify the
        single most likely problem (a disease, pest, or growing/care issue).

        Respond with ONLY valid JSON, no markdown fences, no commentary,
        exactly matching this shape:
        {
          "primary": {
            "name": "short problem name",
            "confidence": "HIGH" | "MEDIUM" | "LOW",
            "whatToDo": ["short actionable step", "short actionable step"]
          },
          "alternatives": [
            {
              "name": "short problem name",
              "confidence": "HIGH" | "MEDIUM" | "LOW",
              "whatToDo": ["short actionable step"]
            }
          ]
        }

        Include 0-2 alternatives only if genuinely plausible from the photo.
        Keep whatToDo steps short and practical for a UK beginner gardener.
        If the photo doesn't show a clear problem, say so honestly in "name"
        with LOW confidence rather than guessing.
    """.trimIndent()

    suspend fun diagnose(imageFile: File): AiDiagnosisResult = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.ANTHROPIC_API_KEY
        if (apiKey.isBlank()) {
            return@withContext AiDiagnosisResult.Failure(
                "No Anthropic API key configured. Add ANTHROPIC_API_KEY to local.properties " +
                    "(see local.properties.example) and rebuild. Note: unlike Pl@ntNet's free " +
                    "tier, this call is paid per use on your Anthropic account."
            )
        }

        try {
            val base64Image = Base64.getEncoder().encodeToString(imageFile.readBytes())

            val requestBody = JSONObject().apply {
                put("model", MODEL)
                put("max_tokens", 1024)
                put("messages", JSONArray().put(
                    JSONObject().apply {
                        put("role", "user")
                        put("content", JSONArray()
                            .put(JSONObject().apply {
                                put("type", "image")
                                put("source", JSONObject().apply {
                                    put("type", "base64")
                                    put("media_type", "image/jpeg")
                                    put("data", base64Image)
                                })
                            })
                            .put(JSONObject().apply {
                                put("type", "text")
                                put("text", prompt)
                            })
                        )
                    }
                ))
            }

            val request = Request.Builder()
                .url(URL)
                .addHeader("x-api-key", apiKey)
                .addHeader("anthropic-version", "2023-06-01")
                .addHeader("content-type", "application/json")
                .post(requestBody.toString().toRequestBody("application/json".toMediaType()))
                .build()

            client.newCall(request).execute().use { response ->
                val bodyString = response.body?.string().orEmpty()

                if (!response.isSuccessful) {
                    if (response.code == 429) {
                        return@withContext AiDiagnosisResult.Failure(
                            "Rate limited by Anthropic — wait a moment and try again."
                        )
                    }
                    val message = try {
                        JSONObject(bodyString).optJSONObject("error")?.optString("message")
                    } catch (e: Exception) {
                        null
                    } ?: "Server returned ${response.code}"
                    return@withContext AiDiagnosisResult.Failure(message)
                }

                val text = extractText(bodyString)
                    ?: return@withContext AiDiagnosisResult.Failure("Empty response from the AI scan.")

                AiDiagnosisResult.Success(parseDiagnosis(text))
            }
        } catch (e: java.io.IOException) {
            AiDiagnosisResult.Failure("Couldn't reach the AI scan service — check your internet connection.")
        } catch (e: Exception) {
            AiDiagnosisResult.Failure("Couldn't read the AI scan result: ${e.message}")
        }
    }

    private fun extractText(body: String): String? {
        val content = JSONObject(body).optJSONArray("content") ?: return null
        for (i in 0 until content.length()) {
            val block = content.getJSONObject(i)
            if (block.optString("type") == "text") return block.optString("text")
        }
        return null
    }

    private fun parseDiagnosis(rawText: String): DiagnosisResult {
        // Strip accidental markdown fences in case the model adds them anyway.
        val cleaned = rawText.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val json = JSONObject(cleaned)

        val primaryJson = json.getJSONObject("primary")
        val primary = toProblem(primaryJson)

        val alternatives = mutableListOf<PossibleProblem>()
        val altArray = json.optJSONArray("alternatives")
        if (altArray != null) {
            for (i in 0 until altArray.length()) {
                alternatives.add(toProblem(altArray.getJSONObject(i)))
            }
        }

        return DiagnosisResult(primary, alternatives)
    }

    private fun toProblem(obj: JSONObject): PossibleProblem {
        val name = obj.optString("name", "Unknown")
        val confidence = when (obj.optString("confidence").uppercase()) {
            "HIGH" -> Confidence.HIGH
            "MEDIUM" -> Confidence.MEDIUM
            else -> Confidence.LOW
        }
        val steps = mutableListOf<String>()
        val stepsArray = obj.optJSONArray("whatToDo")
        if (stepsArray != null) {
            for (i in 0 until stepsArray.length()) steps.add(stepsArray.getString(i))
        }
        return PossibleProblem(name, confidence, steps, guessIcon(name))
    }

    /** No structured category from the AI, so infer a reasonable icon from keywords in the name. */
    private fun guessIcon(name: String): ProblemIcon {
        val n = name.lowercase()
        return when {
            "aphid" in n -> ProblemIcon.APHID
            "slug" in n || "snail" in n -> ProblemIcon.SLUG_SNAIL
            "caterpillar" in n -> ProblemIcon.CATERPILLAR
            "mildew" in n -> ProblemIcon.MILDEW
            "rot" in n -> ProblemIcon.FRUIT_ROT
            "sun" in n || "scald" in n || "heat" in n -> ProblemIcon.SUN_DAMAGE
            "water" in n || "drought" in n -> ProblemIcon.WATERING
            "wilt" in n -> ProblemIcon.WILT_DISEASE
            "nitrogen" in n || "nutrient" in n || "deficien" in n -> ProblemIcon.NUTRIENT
            "pollinat" in n -> ProblemIcon.POLLINATION
            "age" in n || "ageing" in n || "aging" in n -> ProblemIcon.AGEING
            "spot" in n || "blight" in n || "fung" in n || "bacter" in n -> ProblemIcon.LEAF_SPOT
            else -> ProblemIcon.UNCLEAR
        }
    }
}
