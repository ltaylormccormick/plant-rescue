package com.plantrescue.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.plantrescue.app.ui.PlantRescueApp
import com.plantrescue.app.ui.theme.PlantRescueTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PlantRescueTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    PlantRescueApp()
                }
            }
        }
    }
}
