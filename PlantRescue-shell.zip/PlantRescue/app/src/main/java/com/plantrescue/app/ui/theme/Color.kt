package com.plantrescue.app.ui.theme

import androidx.compose.ui.graphics.Color

// Core "grow" greens
val LeafGreen = Color(0xFF2E7D32)
val LeafGreenLight = Color(0xFF66BB6A)
val LeafGreenContainer = Color(0xFFE8F5E9)

// Soil / earth tones for warmth and grounding
val Soil = Color(0xFF6D4C29)
val SoilLight = Color(0xFFEFE3D3)

// Subtle "rescue" accent — used sparingly (diagnose actions, alerts), never clinical red
val RescueCoral = Color(0xFFE2725B)
val RescueCoralContainer = Color(0xFFFBE4DF)

val Cream = Color(0xFFFAF7F0)
val CharcoalText = Color(0xFF23291F)
