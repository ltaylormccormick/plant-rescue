package com.plantrescue.app.ui

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.plantrescue.app.ui.screens.HomeScreen
import com.plantrescue.app.ui.screens.PlaceholderScreen

@Composable
fun PlantRescueApp() {
    val navController: NavHostController = rememberNavController()

    NavHost(navController = navController, startDestination = PlantRescueDestination.HOME.route) {

        composable(PlantRescueDestination.HOME.route) {
            HomeScreen(onNavigate = { destination -> navController.navigate(destination.route) })
        }

        composable(PlantRescueDestination.IDENTIFY.route) {
            PlaceholderScreen(
                title = "Identify My Plant",
                description = "Stage 2 build: photo capture → Pl@ntNet API → likely plant, " +
                    "confidence and basic UK growing info.",
                onBack = { navController.popBackStack() }
            )
        }

        composable(PlantRescueDestination.DIAGNOSE.route) {
            PlaceholderScreen(
                title = "Something's Wrong",
                description = "Stage 3 build: photo + guided questions (symptom, location, " +
                    "speed of onset, soil condition) → built-in diagnostic rules → likely " +
                    "problem, confidence and an action plan.",
                onBack = { navController.popBackStack() }
            )
        }

        composable(PlantRescueDestination.GROW.route) {
            PlaceholderScreen(
                title = "Grow My Own",
                description = "Stage 1/4 build: browsable UK crop database (~20-25 crops) " +
                    "with sowing/harvest windows and growing basics.",
                onBack = { navController.popBackStack() }
            )
        }

        composable(PlantRescueDestination.MY_GARDEN.route) {
            PlaceholderScreen(
                title = "My Garden",
                description = "Stage 4 build: the crops you're growing, with health history, " +
                    "photos, notes and harvest info, stored locally.",
                onBack = { navController.popBackStack() }
            )
        }

        composable(PlantRescueDestination.WHAT_TO_DO.route) {
            PlaceholderScreen(
                title = "What Do I Do Now?",
                description = "Stage 4 build: a short, current list of tasks for your saved " +
                    "plants — not a wall of text.",
                onBack = { navController.popBackStack() }
            )
        }
    }
}
