package com.plantrescue.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = LeafGreen,
    onPrimary = Cream,
    primaryContainer = LeafGreenContainer,
    onPrimaryContainer = CharcoalText,
    secondary = RescueCoral,
    onSecondary = Cream,
    secondaryContainer = RescueCoralContainer,
    onSecondaryContainer = CharcoalText,
    tertiary = Soil,
    background = Cream,
    onBackground = CharcoalText,
    surface = Cream,
    onSurface = CharcoalText,
    surfaceVariant = SoilLight
)

private val DarkColors = darkColorScheme(
    primary = LeafGreenLight,
    onPrimary = CharcoalText,
    primaryContainer = LeafGreen,
    onPrimaryContainer = Cream,
    secondary = RescueCoral,
    onSecondary = CharcoalText,
    background = Color(0xFF161C14),
    onBackground = Cream,
    surface = Color(0xFF1E251B),
    onSurface = Cream
)

@Composable
fun PlantRescueTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colors,
        typography = PlantRescueTypography,
        content = content
    )
}
