package com.plantrescue.app.diagnosis

/** The four guided questions from the brief (section 4). */
enum class Symptom(val label: String) {
    BROWN_SPOTS("Brown spots"),
    YELLOW_LEAVES("Yellow leaves"),
    WILTING("Wilting"),
    HOLES("Holes"),
    WHITE_COATING("White coating"),
    CURLING_LEAVES("Curling leaves"),
    POOR_FRUIT("Poor fruit development"),
    OTHER("Other")
}

enum class Location(val label: String) {
    LOWER_LEAVES("Lower leaves"),
    UPPER_LEAVES("Upper leaves"),
    STEM("Stem"),
    FRUIT("Fruit"),
    WHOLE_PLANT("Whole plant")
}

enum class Speed(val label: String) {
    DAYS("Days"),
    WEEKS("Weeks"),
    GRADUALLY("Gradually")
}

enum class SoilWetness(val label: String) {
    WET("Yes"),
    DRY("No"),
    UNKNOWN("Don't know")
}

enum class Confidence { HIGH, MEDIUM, LOW }

data class DiagnosisAnswers(
    val symptom: Symptom,
    val location: Location,
    val speed: Speed,
    val soilWetness: SoilWetness
)

data class PossibleProblem(
    val name: String,
    val confidence: Confidence,
    val whatToDo: List<String>
)

data class DiagnosisResult(
    val primary: PossibleProblem,
    val alternatives: List<PossibleProblem>
)

/**
 * Combines the photo(future)/question answers using a built-in rules table
 * rather than an AI call, per the brief's cost-control approach (section 12):
 * common problems are handled entirely locally.
 */
object DiagnosisEngine {

    fun diagnose(answers: DiagnosisAnswers): DiagnosisResult = when (answers.symptom) {
        Symptom.BROWN_SPOTS -> brownSpots(answers)
        Symptom.YELLOW_LEAVES -> yellowLeaves(answers)
        Symptom.WILTING -> wilting(answers)
        Symptom.HOLES -> holes(answers)
        Symptom.WHITE_COATING -> whiteCoating()
        Symptom.CURLING_LEAVES -> curlingLeaves(answers)
        Symptom.POOR_FRUIT -> poorFruit(answers)
        Symptom.OTHER -> unclear()
    }

    private fun brownSpots(a: DiagnosisAnswers): DiagnosisResult {
        return if (a.soilWetness == SoilWetness.WET && a.speed == Speed.DAYS) {
            DiagnosisResult(
                primary = PossibleProblem(
                    "Blight", Confidence.HIGH,
                    listOf(
                        "Remove and bin (don't compost) affected leaves straight away",
                        "Avoid watering onto the leaves — water at the base instead",
                        "Improve airflow around the plant, e.g. space plants out or remove lower leaves",
                        "Consider an approved fungicide if it keeps spreading"
                    )
                ),
                alternatives = listOf(
                    PossibleProblem("Fungal leaf spot", Confidence.MEDIUM, genericLeafSpotActions),
                    PossibleProblem("Bacterial spot", Confidence.LOW, genericLeafSpotActions)
                )
            )
        } else if (a.location == Location.FRUIT) {
            DiagnosisResult(
                primary = PossibleProblem(
                    "Blossom end rot", Confidence.MEDIUM,
                    listOf(
                        "Water more consistently — irregular watering is the usual cause",
                        "Mulch around the base to help the soil retain moisture",
                        "Affected fruit won't recover, but new fruit should be fine once watering is steady"
                    )
                ),
                alternatives = listOf(PossibleProblem("Sunscald", Confidence.LOW, sunscaldActions))
            )
        } else {
            DiagnosisResult(
                primary = PossibleProblem("Fungal leaf spot", Confidence.MEDIUM, genericLeafSpotActions),
                alternatives = listOf(
                    PossibleProblem("Bacterial spot", Confidence.LOW, genericLeafSpotActions),
                    PossibleProblem("Blight", Confidence.LOW, genericLeafSpotActions)
                )
            )
        }
    }

    private fun yellowLeaves(a: DiagnosisAnswers): DiagnosisResult {
        return if (a.soilWetness == SoilWetness.WET) {
            DiagnosisResult(
                primary = PossibleProblem(
                    "Overwatering / root rot", Confidence.MEDIUM,
                    listOf(
                        "Let the soil dry out between waterings",
                        "Check the pot or bed drains well — sitting water is the main culprit",
                        "If in a container, check the roots aren't dark, mushy or smelly"
                    )
                ),
                alternatives = listOf(PossibleProblem("Nitrogen deficiency", Confidence.LOW, nitrogenActions))
            )
        } else if (a.location == Location.LOWER_LEAVES && a.speed == Speed.GRADUALLY) {
            DiagnosisResult(
                primary = PossibleProblem("Nitrogen deficiency", Confidence.MEDIUM, nitrogenActions),
                alternatives = listOf(
                    PossibleProblem("Natural ageing (older leaves die back)", Confidence.LOW, listOf(
                        "If it's just the lowest, oldest leaves and the rest of the plant looks healthy, this can be completely normal"
                    ))
                )
            )
        } else {
            DiagnosisResult(
                primary = PossibleProblem("Nutrient deficiency", Confidence.LOW, nitrogenActions),
                alternatives = listOf(PossibleProblem("Overwatering / root rot", Confidence.LOW, listOf(
                    "Double check the soil isn't staying wet for long periods"
                )))
            )
        }
    }

    private fun wilting(a: DiagnosisAnswers): DiagnosisResult {
        return if (a.soilWetness == SoilWetness.DRY) {
            DiagnosisResult(
                primary = PossibleProblem(
                    "Underwatering", Confidence.HIGH,
                    listOf(
                        "Water thoroughly and check again in a few hours — wilted plants often bounce back",
                        "Mulch around the base to help the soil hold moisture",
                        "In hot weather, water in the early morning or evening rather than midday"
                    )
                ),
                alternatives = emptyList()
            )
        } else if (a.soilWetness == SoilWetness.WET) {
            DiagnosisResult(
                primary = PossibleProblem(
                    "Overwatering / root rot", Confidence.MEDIUM,
                    listOf(
                        "Ease off watering and let the soil dry out somewhat",
                        "Improve drainage if the roots are sitting in water",
                        "Check the roots — dark, mushy or smelly roots confirm root rot"
                    )
                ),
                alternatives = listOf(PossibleProblem("Wilt disease (e.g. fusarium/verticillium)", Confidence.LOW, wiltDiseaseActions))
            )
        } else {
            DiagnosisResult(
                primary = PossibleProblem("Wilt disease (e.g. fusarium/verticillium)", Confidence.LOW, wiltDiseaseActions),
                alternatives = listOf(PossibleProblem("Underwatering", Confidence.LOW, listOf("Try watering thoroughly and see if it recovers")))
            )
        }
    }

    private fun holes(a: DiagnosisAnswers): DiagnosisResult {
        val slugsSnails = PossibleProblem(
            "Slugs or snails", Confidence.HIGH,
            listOf(
                "Check the plant at night with a torch — that's when they're active",
                "Look for slime trails nearby",
                "Try organic controls: beer traps, copper tape, or encouraging birds and hedgehogs"
            )
        )
        val caterpillars = PossibleProblem(
            "Caterpillars", Confidence.MEDIUM,
            listOf(
                "Check leaves (especially undersides) for caterpillars and remove by hand",
                "Look for small dark droppings nearby, a giveaway sign",
                "Netting can help prevent egg-laying butterflies/moths reaching the plant"
            )
        )
        return if (a.location == Location.LOWER_LEAVES) {
            DiagnosisResult(slugsSnails, listOf(caterpillars))
        } else {
            DiagnosisResult(caterpillars, listOf(slugsSnails))
        }
    }

    private fun whiteCoating(): DiagnosisResult = DiagnosisResult(
        primary = PossibleProblem(
            "Powdery mildew", Confidence.HIGH,
            listOf(
                "Remove badly affected leaves",
                "Improve airflow — space plants out, avoid overcrowding",
                "Water at the base, not over the leaves",
                "An approved fungicide can help if it's spreading fast"
            )
        ),
        alternatives = emptyList()
    )

    private fun curlingLeaves(a: DiagnosisAnswers): DiagnosisResult {
        return if (a.soilWetness == SoilWetness.DRY) {
            DiagnosisResult(
                primary = PossibleProblem(
                    "Heat or water stress", Confidence.MEDIUM,
                    listOf(
                        "Water consistently, especially during hot spells",
                        "Provide some shade during the hottest part of the day if possible"
                    )
                ),
                alternatives = listOf(PossibleProblem("Aphids", Confidence.LOW, aphidActions))
            )
        } else {
            DiagnosisResult(
                primary = PossibleProblem("Aphids", Confidence.MEDIUM, aphidActions),
                alternatives = listOf(PossibleProblem("Herbicide drift from nearby spraying", Confidence.LOW, listOf(
                    "If this appeared suddenly across many plants after nearby spraying, this could be the cause — there's no fix, just wait it out"
                )))
            )
        }
    }

    private fun poorFruit(a: DiagnosisAnswers): DiagnosisResult = DiagnosisResult(
        primary = PossibleProblem(
            "Poor pollination", Confidence.MEDIUM,
            listOf(
                "Hand-pollinate flowers with a soft brush if pollinators are scarce",
                "Attract pollinators by growing flowers nearby",
                "Very high heat during flowering can also stop fruit setting — some shade may help"
            )
        ),
        alternatives = listOf(
            PossibleProblem("Too much nitrogen (lots of leaf, little fruit)", Confidence.LOW, listOf(
                "Ease off nitrogen-heavy feed and switch to a potassium-rich tomato/fruit feed"
            )),
            PossibleProblem("Inconsistent watering", Confidence.LOW, listOf(
                "Keep watering as regular as you can — irregular watering can affect fruit set too"
            ))
        )
    )

    private fun unclear(): DiagnosisResult = DiagnosisResult(
        primary = PossibleProblem(
            "Not clear from this alone", Confidence.LOW,
            listOf(
                "Try a clear, well-lit close-up photo of the affected part",
                "A second opinion from a local gardening group or forum can help with unusual cases"
            )
        ),
        alternatives = emptyList()
    )

    private val genericLeafSpotActions = listOf(
        "Remove and bin affected leaves",
        "Improve airflow around the plant",
        "Avoid watering onto the leaves — water at the base instead"
    )
    private val nitrogenActions = listOf(
        "Feed with a balanced or nitrogen-rich fertiliser",
        "Check you're not overwatering at the same time, which can wash nutrients away"
    )
    private val sunscaldActions = listOf(
        "Provide some shade during the hottest part of the day",
        "Avoid removing too many leaves at once, which exposes fruit to direct sun"
    )
    private val wiltDiseaseActions = listOf(
        "Badly affected plants often don't recover — remove them to stop spread",
        "Avoid growing the same crop in that exact spot next year",
        "Look for resistant varieties next time you sow"
    )
    private val aphidActions = listOf(
        "Check the underside of leaves and new growth for small green/black insects",
        "Spray with a dilute soapy water solution, covering leaf undersides",
        "Ladybirds and hoverflies are natural predators — plants like marigolds can attract them"
    )
}
