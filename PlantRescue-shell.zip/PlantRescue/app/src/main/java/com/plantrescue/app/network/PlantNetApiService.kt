package com.plantrescue.app.network

import com.plantrescue.app.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * One candidate species returned by Pl@ntNet, simplified down to what the
 * Identify screen needs to show (brief section 4: "likely plant, confidence,
 * basic UK growing info" — the UK-growing-info part comes from our own crop
 * database later, not from Pl@ntNet).
 */
data class PlantMatch(
    val scientificName: String,
    val commonName: String?,
    val confidencePercent: Int
)

sealed class IdentifyResult {
    data class Success(val matches: List<PlantMatch>) : IdentifyResult()
    data class Failure(val message: String) : IdentifyResult()
}

/**
 * Thin wrapper around the Pl@ntNet v2 identify endpoint.
 * Docs: https://my.plantnet.org/doc/api/identify
 *
 * Uses the "k-world-flora" project — Pl@ntNet's baseline KT (Kew-TDWG)
 * project covering all species, guaranteed to exist. Pl@ntNet retired the
 * old "western-europe" legacy project name, so this avoids relying on a
 * region-specific project ID that could be renamed again. A future
 * improvement: call GET /v2/projects with lat/lon to pick the nearest
 * UK-specific KT project automatically for tighter results.
 */
object PlantNetApiService {

    private const val BASE_URL = "https://my-api.plantnet.org/v2/identify/k-world-flora"

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun identify(imageFiles: List<File>): IdentifyResult = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.PLANTNET_API_KEY
        if (apiKey.isBlank()) {
            return@withContext IdentifyResult.Failure(
                "No Pl@ntNet API key configured. Add PLANTNET_API_KEY to local.properties " +
                    "(see local.properties.example) and rebuild."
            )
        }
        if (imageFiles.isEmpty()) {
            return@withContext IdentifyResult.Failure("No photo selected.")
        }

        try {
            val bodyBuilder = MultipartBody.Builder().setType(MultipartBody.FORM)
            for (file in imageFiles) {
                bodyBuilder.addFormDataPart(
                    "images",
                    file.name,
                    file.asRequestBody("image/*".toMediaType())
                )
                // "auto" lets Pl@ntNet infer which part of the plant is shown,
                // rather than making a beginner pick leaf/flower/fruit/bark up front.
                bodyBuilder.addFormDataPart("organs", "auto")
            }

            val url = "$BASE_URL?api-key=$apiKey&lang=en"
            val request = Request.Builder()
                .url(url)
                .post(bodyBuilder.build())
                .build()

            client.newCall(request).execute().use { response ->
                val bodyString = response.body?.string().orEmpty()

                if (!response.isSuccessful) {
                    val message = parseErrorMessage(bodyString) ?: "Server returned ${response.code}"
                    return@withContext IdentifyResult.Failure(message)
                }

                IdentifyResult.Success(parseMatches(bodyString))
            }
        } catch (e: IOException) {
            IdentifyResult.Failure("Couldn't reach Pl@ntNet — check your internet connection.")
        } catch (e: Exception) {
            IdentifyResult.Failure("Something went wrong reading the result: ${e.message}")
        }
    }

    private fun parseErrorMessage(body: String): String? = try {
        JSONObject(body).optString("message").ifBlank { null }
    } catch (e: Exception) {
        null
    }

    private fun parseMatches(body: String): List<PlantMatch> {
        val results = JSONObject(body).optJSONArray("results") ?: return emptyList()
        val matches = mutableListOf<PlantMatch>()

        for (i in 0 until minOf(results.length(), 5)) {
            val result = results.getJSONObject(i)
            val species = result.optJSONObject("species") ?: continue

            val scientificName = species.optString("scientificNameWithoutAuthor").ifBlank {
                species.optString("scientificName", "Unknown species")
            }

            val commonNames = species.optJSONArray("commonNames")
            val commonName = if (commonNames != null && commonNames.length() > 0) {
                commonNames.getString(0)
            } else null

            val confidencePercent = (result.optDouble("score", 0.0) * 100).toInt()

            matches.add(PlantMatch(scientificName, commonName, confidencePercent))
        }

        return matches
    }
}
