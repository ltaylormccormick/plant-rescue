package com.plantrescue.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material.icons.filled.LocalFlorist
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.plantrescue.app.ui.PlantRescueDestination

/**
 * The main screen a beginner gardener sees first. Deliberately simple:
 * five big, obvious actions — no menus, no jargon (see brief section 15).
 */
@Composable
fun HomeScreen(onNavigate: (PlantRescueDestination) -> Unit) {
    Scaffold { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(padding)
                .padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "🌱 Plant Rescue",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "Identify • Diagnose • Grow",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onBackground
            )

            Spacer(modifier = Modifier.height(32.dp))

            HomeActionButton(
                label = "📸  Identify My Plant",
                icon = Icons.Filled.PhotoCamera,
                containerColor = MaterialTheme.colorScheme.primary
            ) { onNavigate(PlantRescueDestination.IDENTIFY) }

            Spacer(modifier = Modifier.height(14.dp))

            HomeActionButton(
                label = "🩺  Something's Wrong",
                icon = Icons.Filled.MedicalServices,
                containerColor = MaterialTheme.colorScheme.secondary
            ) { onNavigate(PlantRescueDestination.DIAGNOSE) }

            Spacer(modifier = Modifier.height(14.dp))

            HomeActionButton(
                label = "🥕  Grow My Own",
                icon = Icons.Filled.LocalFlorist,
                containerColor = MaterialTheme.colorScheme.tertiary
            ) { onNavigate(PlantRescueDestination.GROW) }

            Spacer(modifier = Modifier.height(14.dp))

            HomeActionButton(
                label = "🌿  My Garden",
                icon = Icons.Filled.Eco,
                containerColor = MaterialTheme.colorScheme.primary
            ) { onNavigate(PlantRescueDestination.MY_GARDEN) }

            Spacer(modifier = Modifier.height(14.dp))

            HomeActionButton(
                label = "📅  What Do I Do Now?",
                icon = Icons.Filled.CalendarToday,
                containerColor = MaterialTheme.colorScheme.secondary
            ) { onNavigate(PlantRescueDestination.WHAT_TO_DO) }
        }
    }
}

@Composable
private fun HomeActionButton(
    label: String,
    icon: ImageVector,
    containerColor: androidx.compose.ui.graphics.Color,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(64.dp),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(containerColor = containerColor)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null)
            Spacer(modifier = Modifier.height(0.dp))
            Text(
                text = "  $label",
                style = MaterialTheme.typography.titleMedium
            )
        }
    }
}
