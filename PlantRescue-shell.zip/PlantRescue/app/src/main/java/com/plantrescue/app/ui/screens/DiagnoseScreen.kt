package com.plantrescue.app.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.Image as ImageIconGlyph
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import com.plantrescue.app.R
import com.plantrescue.app.diagnosis.Confidence
import com.plantrescue.app.diagnosis.DiagnosisAnswers
import com.plantrescue.app.diagnosis.DiagnosisEngine
import com.plantrescue.app.diagnosis.DiagnosisResult
import com.plantrescue.app.diagnosis.Location
import com.plantrescue.app.diagnosis.PossibleProblem
import com.plantrescue.app.diagnosis.ProblemIcon
import com.plantrescue.app.diagnosis.SoilWetness
import com.plantrescue.app.diagnosis.Speed
import com.plantrescue.app.diagnosis.Symptom
import com.plantrescue.app.network.AiDiagnosisResult
import com.plantrescue.app.network.ClaudeDiagnosisService
import kotlinx.coroutines.launch
import java.io.File

private const val TOTAL_STEPS = 4

private enum class DiagnoseMode { QUESTIONS, AI_SCAN }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiagnoseScreen(onBack: () -> Unit) {
    var mode by remember { mutableStateOf<DiagnoseMode?>(null) }

    // Guided-questions flow state
    var step by remember { mutableStateOf(0) }
    var symptom by remember { mutableStateOf<Symptom?>(null) }
    var location by remember { mutableStateOf<Location?>(null) }
    var speed by remember { mutableStateOf<Speed?>(null) }
    var questionResult by remember { mutableStateOf<DiagnosisResult?>(null) }

    // AI scan flow state
    var scanImageUri by remember { mutableStateOf<Uri?>(null) }
    var scanLoading by remember { mutableStateOf(false) }
    var scanResult by remember { mutableStateOf<DiagnosisResult?>(null) }
    var scanError by remember { mutableStateOf<String?>(null) }

    fun resetAll() {
        mode = null
        step = 0; symptom = null; location = null; speed = null; questionResult = null
        scanImageUri = null; scanLoading = false; scanResult = null; scanError = null
    }

    // One tap of back steps back one stage rather than leaving the whole
    // flow, so a mis-tap doesn't lose progress.
    fun stepBack() {
        when {
            mode == DiagnoseMode.QUESTIONS && questionResult != null -> questionResult = null
            mode == DiagnoseMode.QUESTIONS && step > 0 -> step -= 1
            mode == DiagnoseMode.QUESTIONS -> mode = null
            mode == DiagnoseMode.AI_SCAN && scanResult != null -> { scanResult = null; scanImageUri = null }
            mode == DiagnoseMode.AI_SCAN -> mode = null
            else -> onBack()
        }
    }

    BackHandler(onBack = ::stepBack)

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Something's Wrong") },
                navigationIcon = {
                    IconButton(onClick = ::stepBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp)
        ) {
            when (mode) {
                null -> ModeSelect(onChoose = { mode = it })
                DiagnoseMode.QUESTIONS -> {
                    if (questionResult == null) {
                        LinearProgressIndicator(
                            progress = (step + 1) / TOTAL_STEPS.toFloat(),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Column(modifier = Modifier.padding(top = 24.dp)) {
                            when (step) {
                                0 -> QuestionStep(
                                    question = "What are you seeing?",
                                    options = Symptom.entries,
                                    optionLabel = { it.label },
                                    onSelected = { symptom = it; step = 1 }
                                )
                                1 -> QuestionStep(
                                    question = "Where is the damage?",
                                    options = Location.entries,
                                    optionLabel = { it.label },
                                    onSelected = { location = it; step = 2 }
                                )
                                2 -> QuestionStep(
                                    question = "How quickly did it appear?",
                                    options = Speed.entries,
                                    optionLabel = { it.label },
                                    onSelected = { speed = it; step = 3 }
                                )
                                3 -> QuestionStep(
                                    question = "Is the soil wet?",
                                    options = SoilWetness.entries,
                                    optionLabel = { it.label },
                                    onSelected = { wetness ->
                                        questionResult = DiagnosisEngine.diagnose(
                                            DiagnosisAnswers(symptom!!, location!!, speed!!, wetness)
                                        )
                                    }
                                )
                            }
                        }
                    } else {
                        ResultView(result = questionResult!!, onStartOver = { resetAll() })
                    }
                }
                DiagnoseMode.AI_SCAN -> AiScanFlow(
                    imageUri = scanImageUri,
                    onImageSelected = { scanImageUri = it },
                    loading = scanLoading,
                    onLoadingChange = { scanLoading = it },
                    result = scanResult,
                    onResult = { scanResult = it },
                    error = scanError,
                    onError = { scanError = it },
                    onStartOver = { resetAll() }
                )
            }
        }
    }
}

@Composable
private fun ModeSelect(onChoose: (DiagnoseMode) -> Unit) {
    Text(
        text = "How would you like to check your plant?",
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold
    )
    Spacer(modifier = Modifier.height(20.dp))

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Checklist, contentDescription = null)
                Spacer(modifier = Modifier.width(10.dp))
                Text("Answer a few questions", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
            Text(
                text = "Free. Four quick questions, answered locally on your phone — no internet call needed.",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 6.dp, bottom = 12.dp)
            )
            Button(onClick = { onChoose(DiagnoseMode.QUESTIONS) }, modifier = Modifier.fillMaxWidth()) {
                Text("Start")
            }
        }
    }

    Spacer(modifier = Modifier.height(14.dp))

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.AutoAwesome, contentDescription = null)
                Spacer(modifier = Modifier.width(10.dp))
                Text("Scan with AI", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.width(8.dp))
                Text("PRO", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
            }
            Text(
                text = "One photo, instant result — no questions needed. Uses a paid AI call each time.",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 6.dp, bottom = 12.dp)
            )
            Button(onClick = { onChoose(DiagnoseMode.AI_SCAN) }, modifier = Modifier.fillMaxWidth()) {
                Text("Start")
            }
        }
    }
}

@Composable
private fun <T> QuestionStep(
    question: String,
    options: List<T>,
    optionLabel: (T) -> String,
    onSelected: (T) -> Unit
) {
    Text(text = question, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        options.forEach { option ->
            OutlinedButton(
                onClick = { onSelected(option) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(optionLabel(option))
            }
        }
    }
}

@Composable
private fun AiScanFlow(
    imageUri: Uri?,
    onImageSelected: (Uri) -> Unit,
    loading: Boolean,
    onLoadingChange: (Boolean) -> Unit,
    result: DiagnosisResult?,
    onResult: (DiagnosisResult) -> Unit,
    error: String?,
    onError: (String?) -> Unit,
    onStartOver: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pendingCameraUri by remember { mutableStateOf<Uri?>(null) }

    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri -> if (uri != null) { onImageSelected(uri); onError(null) } }

    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success -> if (success && pendingCameraUri != null) { onImageSelected(pendingCameraUri!!); onError(null) } }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            val uri = createDiagnoseCameraOutputUri(context)
            pendingCameraUri = uri
            cameraLauncher.launch(uri)
        }
    }

    fun launchCamera() {
        val hasPermission = androidx.core.content.ContextCompat.checkSelfPermission(
            context, Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED

        if (hasPermission) {
            val uri = createDiagnoseCameraOutputUri(context)
            pendingCameraUri = uri
            cameraLauncher.launch(uri)
        } else {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    fun runScan() {
        val uri = imageUri ?: return
        onLoadingChange(true)
        onError(null)
        scope.launch {
            val file = copyDiagnoseUriToCacheFile(context, uri)
            if (file == null) {
                onLoadingChange(false)
                onError("Couldn't read that photo — try picking it again.")
                return@launch
            }
            when (val scanResult = ClaudeDiagnosisService.diagnose(file)) {
                is AiDiagnosisResult.Success -> { onLoadingChange(false); onResult(scanResult.result) }
                is AiDiagnosisResult.Failure -> { onLoadingChange(false); onError(scanResult.message) }
            }
        }
    }

    if (result != null) {
        ResultView(result = result, onStartOver = onStartOver)
        return
    }

    Column(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        if (imageUri != null) {
            AsyncImage(
                model = imageUri,
                contentDescription = "Selected plant photo",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp)
                    .clip(RoundedCornerShape(16.dp))
            )
            Spacer(modifier = Modifier.height(16.dp))
        } else {
            Text(
                text = "Take or choose a clear photo of the affected plant.",
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.padding(vertical = 24.dp)
            )
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = { launchCamera() }, modifier = Modifier.weight(1f)) {
                Icon(Icons.Filled.CameraAlt, contentDescription = null)
                Text("  Camera")
            }
            OutlinedButton(
                onClick = {
                    galleryLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                },
                modifier = Modifier.weight(1f)
            ) {
                Icon(ImageIconGlyph, contentDescription = null)
                Text("  Gallery")
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = { runScan() },
            enabled = imageUri != null && !loading,
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) {
            Text("Scan this plant")
        }

        Spacer(modifier = Modifier.height(20.dp))

        if (loading) {
            CircularProgressIndicator()
            Spacer(modifier = Modifier.height(8.dp))
            Text("Asking the AI…", style = MaterialTheme.typography.bodyMedium)
        }
        if (error != null) {
            Text(error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun ResultView(result: DiagnosisResult, onStartOver: () -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Most likely problem",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        item { ProblemCard(problem = result.primary, isPrimary = true) }

        if (result.alternatives.isNotEmpty()) {
            item {
                Text(
                    text = "Other possibilities",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
            items(result.alternatives) { alt -> ProblemCard(problem = alt, isPrimary = false) }
        }

        item {
            Button(
                onClick = onStartOver,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp)
            ) {
                Text("Start over")
            }
        }
    }
}

@Composable
private fun ProblemCard(problem: PossibleProblem, isPrimary: Boolean) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isPrimary) {
                MaterialTheme.colorScheme.secondaryContainer
            } else {
                MaterialTheme.colorScheme.surfaceVariant
            }
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painter = painterResource(id = problemIconRes(problem.icon)),
                    contentDescription = null,
                    modifier = Modifier.size(if (isPrimary) 56.dp else 40.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = problem.name,
                        style = if (isPrimary) MaterialTheme.typography.titleLarge else MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Confidence: ${confidenceLabel(problem.confidence)}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            if (isPrimary) {
                Column(modifier = Modifier.padding(top = 12.dp)) {
                    problem.whatToDo.forEachIndexed { index, step ->
                        Text(
                            text = "${index + 1}. $step",
                            style = MaterialTheme.typography.bodyLarge,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                    }
                }
            }
        }
    }
}

private fun problemIconRes(icon: ProblemIcon): Int = when (icon) {
    ProblemIcon.LEAF_SPOT -> R.drawable.ic_problem_leaf_spot
    ProblemIcon.FRUIT_ROT -> R.drawable.ic_problem_fruit_rot
    ProblemIcon.SUN_DAMAGE -> R.drawable.ic_problem_sun_damage
    ProblemIcon.WATERING -> R.drawable.ic_problem_watering
    ProblemIcon.NUTRIENT -> R.drawable.ic_problem_nutrient
    ProblemIcon.AGEING -> R.drawable.ic_problem_ageing
    ProblemIcon.WILT_DISEASE -> R.drawable.ic_problem_wilt_disease
    ProblemIcon.SLUG_SNAIL -> R.drawable.ic_problem_slug_snail
    ProblemIcon.CATERPILLAR -> R.drawable.ic_problem_caterpillar
    ProblemIcon.MILDEW -> R.drawable.ic_problem_mildew
    ProblemIcon.APHID -> R.drawable.ic_problem_aphid
    ProblemIcon.POLLINATION -> R.drawable.ic_problem_pollination
    ProblemIcon.UNCLEAR -> R.drawable.ic_problem_unclear
}

private fun confidenceLabel(confidence: Confidence): String = when (confidence) {
    Confidence.HIGH -> "High"
    Confidence.MEDIUM -> "Medium"
    Confidence.LOW -> "Low"
}

/** Creates a fresh content:// URI in cache for the camera to write a JPEG into. */
private fun createDiagnoseCameraOutputUri(context: android.content.Context): Uri {
    val imagesDir = File(context.cacheDir, "images").apply { mkdirs() }
    val file = File(imagesDir, "diagnose_capture_${System.currentTimeMillis()}.jpg")
    return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
}

/** Copies whatever URI we have (camera or gallery) into a plain cache File for upload. */
private fun copyDiagnoseUriToCacheFile(context: android.content.Context, uri: Uri): File? = try {
    val imagesDir = File(context.cacheDir, "upload").apply { mkdirs() }
    val outFile = File(imagesDir, "diagnose_upload_${System.currentTimeMillis()}.jpg")
    context.contentResolver.openInputStream(uri)?.use { input ->
        outFile.outputStream().use { output -> input.copyTo(output) }
    }
    outFile
} catch (e: Exception) {
    null
}
