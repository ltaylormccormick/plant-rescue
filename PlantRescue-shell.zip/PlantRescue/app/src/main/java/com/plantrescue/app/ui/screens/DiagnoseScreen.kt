package com.plantrescue.app.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.plantrescue.app.diagnosis.Confidence
import com.plantrescue.app.diagnosis.DiagnosisAnswers
import com.plantrescue.app.diagnosis.DiagnosisEngine
import com.plantrescue.app.diagnosis.DiagnosisResult
import com.plantrescue.app.diagnosis.Location
import com.plantrescue.app.diagnosis.PossibleProblem
import com.plantrescue.app.diagnosis.SoilWetness
import com.plantrescue.app.diagnosis.Speed
import com.plantrescue.app.diagnosis.Symptom

private const val TOTAL_STEPS = 4

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiagnoseScreen(onBack: () -> Unit) {
    var step by remember { mutableStateOf(0) }
    var symptom by remember { mutableStateOf<Symptom?>(null) }
    var location by remember { mutableStateOf<Location?>(null) }
    var speed by remember { mutableStateOf<Speed?>(null) }
    var result by remember { mutableStateOf<DiagnosisResult?>(null) }

    fun reset() {
        step = 0; symptom = null; location = null; speed = null; result = null
    }

    // One tap of back goes back one question (or one step out of the result
    // screen) rather than leaving the whole flow — losing all answers on a
    // mis-tap was frustrating to test with.
    fun stepBack() {
        when {
            result != null -> result = null
            step > 0 -> step -= 1
            else -> onBack()
        }
    }

    BackHandler(onBack = ::stepBack)

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Something's Wrong") },
                navigationIcon = {
                    IconButton(onClick = ::stepBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp)
        ) {
            if (result == null) {
                LinearProgressIndicator(
                    progress = (step + 1) / TOTAL_STEPS.toFloat(),
                    modifier = Modifier.fillMaxWidth()
                )
                Column(modifier = Modifier.padding(top = 24.dp)) {
                    when (step) {
                        0 -> QuestionStep(
                            question = "What are you seeing?",
                            options = Symptom.entries,
                            optionLabel = { it.label },
                            onSelected = { symptom = it; step = 1 }
                        )
                        1 -> QuestionStep(
                            question = "Where is the damage?",
                            options = Location.entries,
                            optionLabel = { it.label },
                            onSelected = { location = it; step = 2 }
                        )
                        2 -> QuestionStep(
                            question = "How quickly did it appear?",
                            options = Speed.entries,
                            optionLabel = { it.label },
                            onSelected = { speed = it; step = 3 }
                        )
                        3 -> QuestionStep(
                            question = "Is the soil wet?",
                            options = SoilWetness.entries,
                            optionLabel = { it.label },
                            onSelected = { wetness ->
                                result = DiagnosisEngine.diagnose(
                                    DiagnosisAnswers(symptom!!, location!!, speed!!, wetness)
                                )
                            }
                        )
                    }
                }
            } else {
                ResultView(result = result!!, onStartOver = { reset() })
            }
        }
    }
}

@Composable
private fun <T> QuestionStep(
    question: String,
    options: List<T>,
    optionLabel: (T) -> String,
    onSelected: (T) -> Unit
) {
    Text(text = question, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        options.forEach { option ->
            OutlinedButton(
                onClick = { onSelected(option) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(optionLabel(option))
            }
        }
    }
}

@Composable
private fun ResultView(result: DiagnosisResult, onStartOver: () -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Most likely problem",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        item { ProblemCard(problem = result.primary, isPrimary = true) }

        if (result.alternatives.isNotEmpty()) {
            item {
                Text(
                    text = "Other possibilities",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
            items(result.alternatives) { alt -> ProblemCard(problem = alt, isPrimary = false) }
        }

        item {
            Button(
                onClick = onStartOver,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp)
            ) {
                Text("Start over")
            }
        }
    }
}

@Composable
private fun ProblemCard(problem: PossibleProblem, isPrimary: Boolean) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isPrimary) {
                MaterialTheme.colorScheme.secondaryContainer
            } else {
                MaterialTheme.colorScheme.surfaceVariant
            }
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = problem.name,
                style = if (isPrimary) MaterialTheme.typography.titleLarge else MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Confidence: ${confidenceLabel(problem.confidence)}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (isPrimary) {
                Column(modifier = Modifier.padding(top = 12.dp)) {
                    problem.whatToDo.forEachIndexed { index, step ->
                        Text(
                            text = "${index + 1}. $step",
                            style = MaterialTheme.typography.bodyLarge,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                    }
                }
            }
        }
    }
}

private fun confidenceLabel(confidence: Confidence): String = when (confidence) {
    Confidence.HIGH -> "High"
    Confidence.MEDIUM -> "Medium"
    Confidence.LOW -> "Low"
}
