package com.plantrescue.app.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material.icons.filled.LocalFlorist
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * The five main sections of the app, matching the home screen buttons in the
 * project brief: Identify, Diagnose, Grow Your Own, My Garden, What To Do Now.
 */
enum class PlantRescueDestination(
    val route: String,
    val label: String,
    val icon: ImageVector
) {
    HOME("home", "Home", Icons.Filled.Eco),
    IDENTIFY("identify", "Identify My Plant", Icons.Filled.PhotoCamera),
    DIAGNOSE("diagnose", "Something's Wrong", Icons.Filled.MedicalServices),
    GROW("grow", "Grow My Own", Icons.Filled.LocalFlorist),
    MY_GARDEN("my_garden", "My Garden", Icons.Filled.Eco),
    WHAT_TO_DO("what_to_do", "What Do I Do Now?", Icons.Filled.CalendarToday)
}
